import discord 
import os 
import requests 
 
intents = discord.Intents.default() 
intents.message_content = True 
client = discord.Client(intents=intents) 
link=["https://fanswer.me/answer"] 
@client.event 
async def on_ready(): 
    print('We have logged in as {0.user}'.format(client)) 
 
@client.event 
async def on_message(message):             
    if message.channel.id==1001772700294971392: 
        if "https://www.chegg.com"in message.content: 
            msg = message.content 
            print(msg) 
            res=requests.post('https://Account-of-serverr.abc54.repl.co/api/add_message/1234', json={"mytext":msg}) 
            if res.ok: 
                print(res.json()) 
                t=res.json() 
                link.remove(link[0]) 
                link.append(t[0]) 
 
 
                await message.channel.send(link[0]) 
                  
 
            
client.run('OTg0MTc0NjUyODM2NDQ2MjQ4.GgiiWe.5MTm_Ej8-S25Tx5A28-RlItsk9sBQBQmfF4FJ0')